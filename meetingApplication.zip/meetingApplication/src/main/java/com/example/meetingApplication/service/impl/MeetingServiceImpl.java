package com.example.meetingApplication.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.meetingApplication.entities.Meeting;
import com.example.meetingApplication.entities.MeetingUser;
import com.example.meetingApplication.entities.User;
import com.example.meetingApplication.exceptions.MeetingNotFoundException;
import com.example.meetingApplication.exceptions.UserNotFoundException;
import com.example.meetingApplication.repository.MeetingRepository;
import com.example.meetingApplication.repository.MeetingUserRepository;
import com.example.meetingApplication.service.MeetingService;
import com.example.meetingApplication.service.UserService;

@Service
public class MeetingServiceImpl implements MeetingService {

	@Autowired
	UserService userService;
	
	@Autowired
	MeetingRepository meetingRepository;
	
	@Autowired
	MeetingUserRepository meetingUserRepository;
	
	@Override
	@Transactional
	public Meeting create(JSONObject meetingRequest) throws UserNotFoundException {
		
		JSONArray invitees = meetingRequest.getJSONArray("invitees");
		String createdBy = meetingRequest.getString("createdBy");
		
		User creatingUser = userService.getUserById(createdBy);
		
		if(creatingUser == null)
			throw new UserNotFoundException();
		
		Meeting meeting = new Meeting();
		meeting.setCreatedBy(createdBy);
		meetingRepository.save(meeting);
		
		for(int i = 0; i < invitees.length(); i++) {
			
			User user = userService.getUserById(invitees.getString(i));
			if(user == null)
				throw new UserNotFoundException();
			MeetingUser meetingUser = new MeetingUser();
			meetingUser.setMeetingId(meeting.getId());
			meetingUser.setUserId(invitees.getString(i));
			meetingUserRepository.save(meetingUser);
		}		
		
		
		return meeting;
	}

	@Override
	public List<Meeting> getPendingInvites(String userId) throws UserNotFoundException{
		
		User user = userService.getUserById(userId);		
		if(user == null)
			throw new UserNotFoundException();
		//get all records from meetingUser table with user id = userId and pending flag is true; 
		return new ArrayList<Meeting>();
	}

	@Override
	@Transactional
	public List<MeetingUser> acceptInvite(JSONObject acceptInviteRequest) throws UserNotFoundException,MeetingNotFoundException {
		
		String meetingId = acceptInviteRequest.getString("meetingId");
		String userId = acceptInviteRequest.getString("userId");
		
		User user = userService.getUserById(userId);		
		if(user == null)
			throw new UserNotFoundException();
		
		List<MeetingUser> meetingUsers = meetingUserRepository.fingByMeetingIdAndUserId(meetingId, userId);
		
		if(meetingUsers.isEmpty())
			throw new MeetingNotFoundException();
		
		for(MeetingUser meetingUser : meetingUsers) {
			
			meetingUser.setAccepted(true);
			meetingUserRepository.save(meetingUser);
		}
		
		return meetingUsers;
	}
	
	public List<MeetingUser> rejectInvite(JSONObject acceptInviteRequest) throws UserNotFoundException,MeetingNotFoundException {
		
		String meetingId = acceptInviteRequest.getString("meetingId");
		String userId = acceptInviteRequest.getString("userId");
		
		User user = userService.getUserById(userId);		
		if(user == null)
			throw new UserNotFoundException();
		
		List<MeetingUser> meetingUsers = meetingUserRepository.fingByMeetingIdAndUserId(meetingId, userId);
		
		if(meetingUsers.isEmpty())
			throw new MeetingNotFoundException();
		
		for(MeetingUser meetingUser : meetingUsers) {
			
			meetingUser.setAccepted(false);
			meetingUserRepository.save(meetingUser);
		}
		
		return meetingUsers;
	}
}
