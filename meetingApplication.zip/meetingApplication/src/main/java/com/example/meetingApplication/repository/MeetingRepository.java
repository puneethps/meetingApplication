package com.example.meetingApplication.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.meetingApplication.entities.Meeting;

public interface MeetingRepository extends CrudRepository<Meeting, String>{

}
