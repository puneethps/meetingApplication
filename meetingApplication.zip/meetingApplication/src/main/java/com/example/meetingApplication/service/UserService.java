package com.example.meetingApplication.service;

import com.example.meetingApplication.entities.User;

public interface UserService {

	public User getUserById(String userId);
}
