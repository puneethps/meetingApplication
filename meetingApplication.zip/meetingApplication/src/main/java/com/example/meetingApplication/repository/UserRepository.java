package com.example.meetingApplication.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.meetingApplication.entities.User;

public interface UserRepository extends CrudRepository<User, String>{

}
