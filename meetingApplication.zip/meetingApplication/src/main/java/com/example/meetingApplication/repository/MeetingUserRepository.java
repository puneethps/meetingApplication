package com.example.meetingApplication.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.meetingApplication.entities.MeetingUser;

public interface MeetingUserRepository extends CrudRepository<MeetingUser, String> {

	public List<MeetingUser> fingByMeetingIdAndUserId(String meetingId,String userId);
}
