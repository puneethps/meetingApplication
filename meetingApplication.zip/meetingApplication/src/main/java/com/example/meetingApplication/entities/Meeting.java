package com.example.meetingApplication.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Meeting {

	@Id
	@GeneratedValue
	private String id;
		
	private String createdBy;
	

    @OneToMany(
        cascade = CascadeType.ALL,
        orphanRemoval = true
    )
    private List<MeetingUser> meetingUsers = new ArrayList<>();

	public List<MeetingUser> getMeetingUsers() {
		return meetingUsers;
	}

	public void setMeetingUsers(List<MeetingUser> meetingUsers) {
		this.meetingUsers = meetingUsers;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
}
