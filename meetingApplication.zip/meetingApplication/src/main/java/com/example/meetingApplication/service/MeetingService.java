package com.example.meetingApplication.service;

import java.util.List;

import org.json.JSONObject;

import com.example.meetingApplication.entities.Meeting;
import com.example.meetingApplication.entities.MeetingUser;
import com.example.meetingApplication.exceptions.MeetingNotFoundException;
import com.example.meetingApplication.exceptions.UserNotFoundException;

public interface MeetingService {

	public Meeting create(JSONObject meetingRequest) throws UserNotFoundException;
	
	public List<Meeting> getPendingInvites(String userId) throws UserNotFoundException;
	
	public List<MeetingUser> acceptInvite(JSONObject acceptInviteRequest) throws UserNotFoundException,MeetingNotFoundException;

	List<MeetingUser> rejectInvite(JSONObject acceptInviteRequest)
			throws UserNotFoundException, MeetingNotFoundException;
	
}
