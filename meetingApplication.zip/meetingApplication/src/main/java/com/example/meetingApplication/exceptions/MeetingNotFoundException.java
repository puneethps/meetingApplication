package com.example.meetingApplication.exceptions;

public class MeetingNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
