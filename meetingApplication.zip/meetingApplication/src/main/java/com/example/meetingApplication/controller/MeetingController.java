package com.example.meetingApplication.controller;

import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.meetingApplication.entities.Meeting;
import com.example.meetingApplication.exceptions.MeetingNotFoundException;
import com.example.meetingApplication.exceptions.UserNotFoundException;
import com.example.meetingApplication.service.MeetingService;

@RequestMapping("/meeting")
@RestController
public class MeetingController {

	@Autowired
	MeetingService meetingService;
	
	@PostMapping("/create")	
	public ResponseEntity<Object> createMeeting(@RequestBody String meeting) throws UserNotFoundException {
		
		JSONObject createMeetingJsonObject = new JSONObject(meeting);
		meetingService.create(createMeetingJsonObject);
		return new ResponseEntity<>("Meeting created successfully",HttpStatus.OK);
	}
	
	@GetMapping("/viewPending")	
	public ResponseEntity<Object> viewPendingMeetingInvites(@RequestBody String userId) throws UserNotFoundException {
		
		List<Meeting> pendingMeetings = meetingService.getPendingInvites(userId);
		return new ResponseEntity<>(pendingMeetings,HttpStatus.OK);
	}
	
	@PostMapping("/accept")	
	public ResponseEntity<Object> acceptInvites(@RequestBody String meetingRequest) throws UserNotFoundException, MeetingNotFoundException {
		
		JSONObject acceptInviteJsonObject = new JSONObject(meetingRequest);
		meetingService.acceptInvite(acceptInviteJsonObject);
		return new ResponseEntity<>("Meeting accepted successfully",HttpStatus.OK);
	}
}
